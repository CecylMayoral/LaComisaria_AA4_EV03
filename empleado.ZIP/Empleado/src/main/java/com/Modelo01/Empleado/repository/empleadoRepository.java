
package com.Modelo01.Empleado.repository;

import com.Modelo01.Empleado.model.empleado;
import org.springframework.data.jpa.repository.JpaRepository;

public interface empleadoRepository extends JpaRepository<empleado, Integer>{
    
}
