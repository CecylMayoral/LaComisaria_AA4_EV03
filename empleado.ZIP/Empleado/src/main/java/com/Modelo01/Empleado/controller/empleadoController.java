
package com.Modelo01.Empleado.controller;

import com.Modelo01.Empleado.model.empleado;
import com.Modelo01.Empleado.service.empleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

// La anotación @Autowired permite la inyección automática del servicio de categorías
@RequestMapping("/empleado")
public class empleadoController {
    
    @Autowired
    private empleadoService empleadoService;
    
    @PostMapping("/nuevo")
    public empleado NewEmpleado (@RequestBody empleado NewEmpleado) {
        return this.empleadoService.NewEmpleado(NewEmpleado);
    }
    
    @GetMapping("/mostrar")
    public Iterable<empleado> getAll() {
        return empleadoService.getAll();
    } 
    
    @PostMapping("/modificar")
    public empleado updateEmpleado(@RequestBody empleado empleado){
        return this.empleadoService.modifyEmpleado(empleado);
    }
    
    @PostMapping(value = "/{id}")
    public Boolean deleteEmpleado(@PathVariable(value="id") Integer id) {
        return this.empleadoService.deleteEmpleado(id);
    }
    
}
