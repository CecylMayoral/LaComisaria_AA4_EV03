
package com.Modelo01.Empleado.service;

import com.Modelo01.Empleado.model.empleado;


public interface empleadoService {
    empleado NewEmpleado (empleado Newempleado);
    Iterable<empleado> getAll();
    empleado modifyEmpleado (empleado empleado);
    Boolean deleteEmpleado (Integer idEmpleado);
}
