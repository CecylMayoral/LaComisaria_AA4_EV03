
package com.Modelo01.Empleado.service;

import com.Modelo01.Empleado.model.empleado;
import com.Modelo01.Empleado.repository.empleadoRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class empleadoServiceImplement implements empleadoService {

    @Autowired
    private empleadoRepository empleadoRepository;

    @Override
    public empleado NewEmpleado(empleado NewEmpleado) {
        return empleadoRepository.save(NewEmpleado);
    }

    @Override
    public Iterable<empleado> getAll() {
        return this.empleadoRepository.findAll();  
    }

    @Override
    public empleado modifyEmpleado(empleado empleado) {
        Optional<empleado> empleadoEncontrado = this.empleadoRepository.findById(empleado.getIdempleado());
        if (empleadoEncontrado.get()!= null) {
            empleadoEncontrado.get().setCargo(empleado.getCargo());
            empleadoEncontrado.get().setTelefono(empleado.getTelefono());
            return this.NewEmpleado(empleadoEncontrado.get());
    }
        return null;
    }

    @Override
    public Boolean deleteEmpleado(Integer idEmpleado) {
        this.empleadoRepository.deleteById(idEmpleado);
        return true;
    }
    
}
