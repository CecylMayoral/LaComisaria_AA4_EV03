import './App.css';
import 'primeicons/primeicons.css';
import "primereact/resources/themes/lara-dark-purple/theme.css";

import { empleadoService } from './services/empleadoService';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Component, createRef } from 'react';
import { Panel } from 'primereact/panel';  
import { Menubar } from 'primereact/menubar';
import { React} from 'react';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { FloatLabel } from 'primereact/floatlabel';
import { Button } from 'primereact/button';   
import { Toast } from 'primereact/toast';           
        
export default class App extends Component {
    constructor(){
        super();
        this.state = {
            visible : false,
            empleado:{
                idempleado:null,
                telefono:null,
                correo:null,
                apellidos:null,
                cargo:null,
                nombre:null
                },
                selectedEmpleado: null,
                empleados: []
        };
        this.items = [
            {
                label: "Nuevo",
                icon: "pi pi-fw pi-user-plus",
                command: () => {this.showSaveDialog()}
            },
            {
                label: "Editar",
                icon: "pi pi-fw pi-user-edit",
                command: () => {this.showEditDialog()}
            },
            {
                label: "Eliminar",
                icon: "pi pi-fw pi-user-minus",
                command: () => {this.delete()}
            }
        ];
        this.empleadoService = new empleadoService();
        this.save = this.save.bind(this);
        this.footer = (
            <div>
                <Button label="Guardar" icon="pi pi-check" onClick={this.save}/>
            </div>
        )
        this.Toast = createRef();
    }

    componentDidMount(){
        this.empleadoService.getAll().then(data => this.setState({empleados : data }))              
    }
    
    save(){
        this.empleadoService.save(this.state.empleado).then(data => {
            this.setState({
                visible : false,
                empleado:{
                    idempleado:null,
                    telefono:null,
                    correo:null,
                    apellidos:null,
                    cargo:null,
                    nombre:null
                    }
            });
            this.Toast.current.show({severity:"success", summary:"Atención!", detail:"Se guardó el registro correctamente"});
            this.empleadoService.getAll().then(data => this.setState({empleados:data }))
        })
    }

delete(){
    if (window.confirm("¿Desea eliminar este registro?")){
        this.empleadoService.delete(this.state.selectedEmpleado.idempleado).then(data => {
            this.Toast.current.show({severity:"success", summary:"Atención!", detail:"Se eliminó el registro correctamente"});
            this.empleadoService.getAll().then(data => this.setState({empleados : data}))
        })
    }
}
    
    render(){
        return (
            <div style={{width:"80%", margin:"20px auto 0px"}}>
                <Menubar model={this.items} />
                <br/>
                <Panel header="Gestión de Empleados">
                <DataTable value = {this.state.empleados} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]}
                selectionMode="single" selection={this.state.selectedEmpleado} onSelectionChange={(e)=>this.setState({selectedEmpleado: e.value})}>
                <Column field='idempleado' header='ID'></Column> 
                <Column field='nombre' header='Nombres'></Column>            
                <Column field='apellidos' header='Apellidos'></Column>            
                <Column field='cargo' header='Cargo'></Column>            
                <Column field='correo' header='Correo'></Column>            
                <Column field='telefono' header='Teléfono'></Column>            
                </DataTable>
                </Panel>

                <Dialog header="Empleados" visible={this.state.visible} style={{ width: '400px' }} footer={this.footer} modal={true} onHide={() => this.setState({visible:false})}>

                <FloatLabel>
                <InputText style={{width:"100%"}} value={this.state.empleado.idempleado} id='idempleado' onChange={(e) => {
                let val = e.target.value;

                this.setState(prevState => {
                    let empleado = Object.assign({}, prevState.empleado);
                    empleado.idempleado = val;
                    return {empleado};
                })}
                } />
                <label htmlFor="idempleado">Id empleado:</label>
                </FloatLabel><br />

                <FloatLabel>
                <InputText style={{width:"100%"}} value={this.state.empleado.nombre} id='nombre' onChange={(e) => {
                let val = e.target.value;

                this.setState(prevState => {
                    let empleado = Object.assign({}, prevState.empleado);
                    empleado.nombre = val;
                    return {empleado};
                })} 
                }/>
                <label htmlFor="nombre">Nombres:</label>
                </FloatLabel><br />

                <FloatLabel>
                <InputText style={{width:"100%"}} value={this.state.empleado.apellidos} id='apellidos' onChange={(e) => {
                let val = e.target.value;

                this.setState(prevState => {
                    let empleado = Object.assign({}, prevState.empleado);
                    empleado.apellidos = val;
                    return {empleado};
                })}
                } />
                <label htmlFor="cargo">Apellidos:</label>
                </FloatLabel><br />

                <FloatLabel>
                <InputText style={{width:"100%"}} value={this.state.empleado.cargo} id='cargo' onChange={(e) => {
                let val = e.target.value;

                this.setState(prevState => {
                    let empleado = Object.assign({}, prevState.empleado);
                    empleado.cargo = val;
                    return {empleado};
                })}
                } />
                <label htmlFor="cargo">Cargo:</label>
                </FloatLabel><br />

                <FloatLabel>
                <InputText style={{width:"100%"}} value={this.state.empleado.correo} id='correo' onChange={(e) => {
                let val = e.target.value;

                this.setState(prevState => {
                    let empleado = Object.assign({}, prevState.empleado);
                    empleado.correo = val;
                    return {empleado};
                })}
                } />
                <label htmlFor="correo">Correo:</label>
                </FloatLabel><br />

                <FloatLabel>
                <InputText style={{width:"100%"}} value={this.state.empleado.telefono} id='telefono' onChange={(e) => {
                let val = e.target.value;

                this.setState(prevState => {
                    let empleado = Object.assign({}, prevState.empleado);
                    empleado.telefono = val;
                    return {empleado};
                })} 
                }/>
                <label htmlFor="telefono">Teléfono:</label>
                </FloatLabel><br />
                </Dialog>
                <Toast ref={this.Toast}/>
            </div>
            );
        }
        showSaveDialog(){
            this.setState({
            visible:true,
            empleado:{
            idempleado:null,
            telefono:null,
            correo:null,
            apellidos:null,
            cargo:null,
            nombre:null
            }
            });
        }
        showEditDialog() {
            if (this.state.selectedEmpleado) {
                this.setState({
                    visible: true,
                    empleado: { ...this.state.selectedEmpleado }
                });
            } else {
                this.Toast.current.show({ severity: "warn", summary: "Atención!", detail: "Debe seleccionar un empleado" });
            }
        }
    }
