import axios from 'axios';

export class empleadoService {
    baseUrl = "http://localhost:8080/empleado";

    getAll() {
        return axios.get(this.baseUrl + "/mostrar").then(res => res.data);
    }
    save(empleado) {
        return axios.post(this.baseUrl + "/nuevo", empleado).then(res => res.data);
    }
    delete(idempleado) {
        return axios.post(this.baseUrl + "/eliminar/" + idempleado).then(res => res.data);
    }
    update(empleado) {
        return axios.post(this.baseUrl + "/modificar", empleado).then(res => res.data);
    }
}
